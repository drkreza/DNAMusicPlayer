package com.sdsmdg.harjot.MusicDNA.interfaces;

import com.sdsmdg.harjot.MusicDNA.fragments.PlayerFragment.PlayerFragment;

/**
 * Created by Harjot on 14-Oct-16.
 */
public interface ServiceCallbacks {
    public PlayerFragment getPlayerFragment();
}
