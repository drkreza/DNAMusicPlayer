package com.sdsmdg.harjot.MusicDNA.itemtouchhelpers;

/**
 * Created by Harjot on 18-May-16.
 */
public interface ItemTouchHelperViewHolder {

    void onItemSelected();

    void onItemClear();
}
